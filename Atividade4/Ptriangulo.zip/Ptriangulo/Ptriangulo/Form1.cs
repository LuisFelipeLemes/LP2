﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double LadoC, LadoA, LadoB;
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out LadoA) ||
             !Double.TryParse(txtLadoB.Text, out LadoB) || !Double.TryParse(txtLadoC.Text, out LadoC) ||
             LadoB <= 0 || LadoC <= 0 || LadoA <= 0) 
            {
                MessageBox.Show("Triangulo Inválido");
                Focus();
            }
            else if ((LadoA<LadoB+LadoC) && (LadoA > Math.Abs(LadoB - LadoC)) && (LadoB < LadoA+LadoC) &&
            (LadoB>Math.Abs(LadoA-LadoC)) && (LadoC<LadoA+LadoB) && (LadoC>Math.Abs(LadoB-LadoA)))
            {
                if(LadoA == LadoB && LadoA == LadoC)
                {
                    MessageBox.Show("É Equilátero");
                }
                else if(LadoA == LadoB && LadoA != LadoC)
                {
                    MessageBox.Show("É Isóleces");
                }
                else if(LadoA != LadoB && LadoA != LadoC)
                {
                    MessageBox.Show("É Escaleno");
                }
            };
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out LadoC))
            {
                MessageBox.Show("Numero inválido");
            }
            else if (LadoC <= 0)
            {
                MessageBox.Show("Numero menor que zero");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out LadoB))
            {
                MessageBox.Show("Numero inválido");
            }
            else if (LadoB <= 0)
            {
                MessageBox.Show("Numero menor que zero");
            }
        }

       

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtLadoA.Text, out LadoA)) {
                MessageBox.Show("Numero inválido");
            }
            else if (LadoA <= 0)
            {
                MessageBox.Show("Numero menor que zero");
            }
        }
    }
}
