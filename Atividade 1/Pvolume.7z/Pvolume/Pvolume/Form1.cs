﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtAltura_Validating(object sender, CancelEventArgs e)
        {

            if (!Double.TryParse(TxtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                //e.Cancel = true;
            }
            else if (altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero");
                //e.Cancel = true;
            }
        }

        private void BtuSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            TxtAltura.Text = string.Empty;
            TxtRaio.Text = string.Empty;
            TxtResultado.Text = string.Empty;
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtRaio.Text, out raio) ||
                !Double.TryParse(TxtAltura.Text, out altura) ||
                raio <= 0 || altura <= 0)
            {
                MessageBox.Show("Entrada Inválida!");
                TxtRaio.Focus();
            }
            else
            {
                resultado = Math.PI * Math.Pow(raio, 2) * altura;
                TxtResultado.Text = resultado.ToString("N2");
            }       
        }

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtRaio.Text, out raio))
            {
                MessageBox.Show("Raio Inválido!");
                //TxtRaio.Focus();
            }
            else if (raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero");
                //TxtRaio.Focus();
            }
        }
    }
}
