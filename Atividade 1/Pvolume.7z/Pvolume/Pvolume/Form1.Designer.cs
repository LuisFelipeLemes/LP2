﻿namespace Pvolume
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblRaio = new System.Windows.Forms.Label();
            this.LblAltura = new System.Windows.Forms.Label();
            this.LblResultado = new System.Windows.Forms.Label();
            this.TxtRaio = new System.Windows.Forms.TextBox();
            this.TxtResultado = new System.Windows.Forms.TextBox();
            this.TxtAltura = new System.Windows.Forms.TextBox();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.BtuSair = new System.Windows.Forms.Button();
            this.Btnlimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblRaio
            // 
            this.LblRaio.AutoSize = true;
            this.LblRaio.Location = new System.Drawing.Point(163, 102);
            this.LblRaio.Name = "LblRaio";
            this.LblRaio.Size = new System.Drawing.Size(42, 20);
            this.LblRaio.TabIndex = 0;
            this.LblRaio.Text = "Raio";
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(163, 238);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(51, 20);
            this.LblAltura.TabIndex = 1;
            this.LblAltura.Text = "Altura";
            // 
            // LblResultado
            // 
            this.LblResultado.AutoSize = true;
            this.LblResultado.Location = new System.Drawing.Point(163, 333);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(82, 20);
            this.LblResultado.TabIndex = 2;
            this.LblResultado.Text = "Resultado";
            // 
            // TxtRaio
            // 
            this.TxtRaio.Location = new System.Drawing.Point(433, 102);
            this.TxtRaio.Name = "TxtRaio";
            this.TxtRaio.Size = new System.Drawing.Size(100, 26);
            this.TxtRaio.TabIndex = 3;
            this.TxtRaio.Validated += new System.EventHandler(this.TxtRaio_Validated);
            // 
            // TxtResultado
            // 
            this.TxtResultado.Enabled = false;
            this.TxtResultado.Location = new System.Drawing.Point(433, 327);
            this.TxtResultado.Name = "TxtResultado";
            this.TxtResultado.Size = new System.Drawing.Size(100, 26);
            this.TxtResultado.TabIndex = 5;
            // 
            // TxtAltura
            // 
            this.TxtAltura.Location = new System.Drawing.Point(433, 190);
            this.TxtAltura.Name = "TxtAltura";
            this.TxtAltura.Size = new System.Drawing.Size(100, 26);
            this.TxtAltura.TabIndex = 4;
            this.TxtAltura.Validating += new System.ComponentModel.CancelEventHandler(this.TxtAltura_Validating);
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(242, 440);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(173, 51);
            this.BtnCalcular.TabIndex = 6;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // BtuSair
            // 
            this.BtuSair.Location = new System.Drawing.Point(487, 440);
            this.BtuSair.Name = "BtuSair";
            this.BtuSair.Size = new System.Drawing.Size(185, 51);
            this.BtuSair.TabIndex = 7;
            this.BtuSair.Text = "Sair";
            this.BtuSair.UseCompatibleTextRendering = true;
            this.BtuSair.UseVisualStyleBackColor = true;
            this.BtuSair.Click += new System.EventHandler(this.BtuSair_Click);
            // 
            // Btnlimpar
            // 
            this.Btnlimpar.Location = new System.Drawing.Point(750, 440);
            this.Btnlimpar.Name = "Btnlimpar";
            this.Btnlimpar.Size = new System.Drawing.Size(213, 51);
            this.Btnlimpar.TabIndex = 8;
            this.Btnlimpar.Text = "Limpar";
            this.Btnlimpar.UseVisualStyleBackColor = true;
            this.Btnlimpar.Click += new System.EventHandler(this.Btnlimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1287, 678);
            this.Controls.Add(this.Btnlimpar);
            this.Controls.Add(this.BtuSair);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.TxtAltura);
            this.Controls.Add(this.TxtResultado);
            this.Controls.Add(this.TxtRaio);
            this.Controls.Add(this.LblResultado);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.LblRaio);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblRaio;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label LblResultado;
        private System.Windows.Forms.TextBox TxtRaio;
        private System.Windows.Forms.TextBox TxtResultado;
        private System.Windows.Forms.TextBox TxtAltura;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.Button BtuSair;
        private System.Windows.Forms.Button Btnlimpar;
    }
}

