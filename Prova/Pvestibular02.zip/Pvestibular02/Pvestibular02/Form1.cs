﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnDados_Click(object sender, EventArgs e)
        {
            int[,] inscricoesVest = new int[2, 5];
            string auxiliar = "";
            int totalCurso = 0;
            int totalGeral = 0;

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o total de alunos do {i + 1}º curso do {j + 1} ano",
                     "Entrada de dados");

                    if (!int.TryParse(auxiliar, out inscricoesVest[i, j]) || inscricoesVest[i,j] < 0)
                    {
                        MessageBox.Show($"Número de inscrições inválida");
                        j--;
                    }
                    else
                    {
                        lstbxVestibular.Items.Add($"Total do curso {i+1} do Ano {j+1}: {inscricoesVest[i,j]} ");
                        totalCurso += inscricoesVest[i, j];
                        totalGeral += inscricoesVest[i, j];
                    }
                    
                }
                lstbxVestibular.Items.Add("");
                lstbxVestibular.Items.Add($"Total do curso {i + 1}: {totalCurso}");
                lstbxVestibular.Items.Add("------------------------------------------------------------");
                totalCurso = 0;
            }
           
            lstbxVestibular.Items.Add($"Total geral: {totalGeral}");
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVestibular.Items.Clear();
        }
    }
}

